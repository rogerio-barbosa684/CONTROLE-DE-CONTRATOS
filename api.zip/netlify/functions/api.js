var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var api_exports = {};
__export(api_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(api_exports);
var import_supabase_js = require("@supabase/supabase-js");
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_crypto = __toESM(require("crypto"), 1);
const JWT_SECRET = process.env.JWT_SECRET || "contratos_jwt_secret_2026_ideal_alimentacao";
const forgotPasswordAttempts = /* @__PURE__ */ new Map();
function checkForgotPasswordRateLimit(ip) {
  const now = Date.now();
  const windowMs = 60 * 1e3;
  const maxAttempts = 3;
  const record = forgotPasswordAttempts.get(ip);
  if (!record || now - record.start > windowMs) {
    forgotPasswordAttempts.set(ip, { start: now, count: 1 });
    return true;
  }
  record.count++;
  if (record.count > maxAttempts) return false;
  return true;
}
let _supabase = null;
function getSupabase() {
  if (_supabase) return _supabase;
  const url = process.env.SUPABASE_URL || "https://pgehubucomamrmdgpvhn.supabase.co";
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || "sb_secret_HRHEyYIEUW0BK7-ZOAS9rA_OQiyyfLm";
  _supabase = (0, import_supabase_js.createClient)(url, key);
  return _supabase;
}
const SYSTEM_PROMPT_ASSISTENTE = `Voce e o Assistente Virtual do sistema CONTROLE DE CONTRATOS E PAGAMENTOS da Ideal Alimentacao.
Seu papel e ajudar o usuario a entender e usar o sistema. Responda SEMPRE em portugues brasileiro, de forma simples e direta.
SOBRE O SISTEMA: Aplicacao web para gerenciar contratos, pagamentos e vencimentos de empresas.
TELAS: 1) Dashboard - resumo com cards e vencimentos. 2) Contratos - lista e gerenciamento. 3) Novo Contrato - formulario de cadastro. 4) Pagamentos - lista de parcelas. 5) Configuracao - Usuarios, Empresas, Tipos, Destinatarios, E-mail.
Cadastrar contrato: clique em "+ Novo Contrato", preencha obrigatorios (Numero, Tipo, Empresa, Objeto, Fornecedor, Valor, Datas), salve.
Registrar pagamento: va em Pagamentos, clique Registrar, informe data, valor, forma de pagamento, confirme.
Aditivo: abra detalhe do contrato, clique Registrar Aditivo, preencha dados, salve.
Email: configure SMTP em Configuracao > E-mail. Envio manual pelos bot\xF5es e automatico as 10h no servidor local.
Usuarios: Configuracao > Usuarios, crie, edite, defina perfil e empresas.
Empresas: Configuracao > Empresas, cadastre nome e CNPJ.`;
function respostaOffline(pergunta) {
  const p = pergunta.toLowerCase();
  if (["contrato", "cadastr", "novo", "criar"].some((w) => p.includes(w)))
    return 'Para cadastrar um contrato, clique em "+ Novo Contrato" no menu. Preencha os campos obrigatorios (Numero, Tipo, Empresa, Objeto, Fornecedor, Valor, Datas) e salve.';
  if (["pagamento", "parcela"].some((w) => p.includes(w)))
    return 'Para registrar um pagamento, va em Pagamentos, clique em "Registrar" ao lado do pagamento pendente, informe data, valor e forma de pagamento, e confirme.';
  if (["editar", "alterar"].some((w) => p.includes(w)))
    return "Para editar, va em Contratos, clique no icone de editar (lapis), altere os dados e salve.";
  if (["aditivo", "prorrog"].some((w) => p.includes(w)))
    return 'Para adicionar um aditivo, abra o detalhe do contrato e clique em "Registrar Aditivo". Preencha os dados e salve.';
  if (["email", "smtp", "alerta", "lembrete"].some((w) => p.includes(w)))
    return "Configure o e-mail em Configuracao > E-mail. Informe servidor SMTP, porta, email remetente e senha. Use os botoes para envio manual.";
  if (["usuario", "senha", "login"].some((w) => p.includes(w)))
    return "Para gerenciar usuarios, va em Configuracao > Usuarios. Crie, edite, defina perfil (admin/usuario) e empresas com acesso.";
  if (["empresa", "cnpj"].some((w) => p.includes(w)))
    return "Para cadastrar empresas, va em Configuracao > Empresas. Informe nome e CNPJ.";
  if (["dashboard", "inicio", "resumo"].some((w) => p.includes(w)))
    return "O Dashboard mostra resumo com cards, proximos vencimentos e contratos. Use os filtros por fornecedor/CNPJ e data.";
  if (["tema", "escuro", "claro"].some((w) => p.includes(w)))
    return "Para mudar o tema, clique no icone da lua/sol no canto superior direito do header.";
  return "Posso ajudar com: cadastro de contratos, pagamentos, aditivos, empresas, usuarios, configuracao de e-mail, uso do dashboard e navegacao no sistema.";
}
function json(data, status = 200, extraHeaders = {}) {
  return {
    statusCode: status,
    headers: { "Content-Type": "application/json", ...extraHeaders },
    body: JSON.stringify(data)
  };
}
function parseCookies(header) {
  const cookies = {};
  if (!header) return cookies;
  header.split(";").forEach((c) => {
    const [k, ...v] = c.trim().split("=");
    if (k) cookies[k.trim()] = v.join("=").trim();
  });
  return cookies;
}
function setCookie(name, value, opts = {}) {
  let s = `${name}=${value}; Path=/; HttpOnly; SameSite=Lax`;
  if (opts.secure) s += "; Secure";
  if (opts.maxAge) s += `; Max-Age=${opts.maxAge}`;
  return s;
}
function getAuthUser(cookieHeader) {
  try {
    const cookies = parseCookies(cookieHeader);
    const token = cookies["token"];
    if (!token) return null;
    return import_jsonwebtoken.default.verify(token, JWT_SECRET);
  } catch {
    return null;
  }
}
function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = import_crypto.default.randomBytes(16).toString("hex");
    import_crypto.default.pbkdf2(password, salt, 31e4, 32, "sha256", (err, key) => {
      if (err) reject(err);
      else resolve(`pbkdf2_sha256$${salt}$${key.toString("hex")}`);
    });
  });
}
function checkPassword(password, hash) {
  return new Promise((resolve, reject) => {
    if (!hash || !hash.includes("$")) return resolve(false);
    const parts = hash.split("$");
    if (parts.length < 3) return resolve(false);
    if (hash.startsWith("scrypt:")) {
      const params = parts[0].split(":");
      const N = parseInt(params[1]) || 32768;
      const r = parseInt(params[2]) || 8;
      const p = parseInt(params[3]) || 1;
      const salt = parts[1];
      const storedHash = parts[2];
      import_crypto.default.scrypt(password, salt, 64, { N, r, p }, (err, key) => {
        if (err) reject(err);
        else resolve(key.toString("hex") === storedHash);
      });
    } else {
      const salt = parts[1];
      const storedHash = parts[2];
      import_crypto.default.pbkdf2(password, salt, 31e4, 32, "sha256", (err, key) => {
        if (err) reject(err);
        else resolve(key.toString("hex") === storedHash);
      });
    }
  });
}
function deriveCsrf(userId) {
  const h = import_crypto.default.createHmac("sha256", JWT_SECRET);
  h.update(String(userId));
  return h.digest("hex");
}
function validateCsrf(user, bodyCsrf) {
  if (!user || !bodyCsrf) return false;
  const sessionCsrf = user._csrfToken || deriveCsrf(user.id);
  return sessionCsrf === bodyCsrf;
}
function requireAdmin(user) {
  if (!user || user.role !== "admin" && user.role !== "setor_admin") {
    return json({ ok: false, erro: "Acesso restrito ao administrador" }, 403);
  }
  return null;
}
function requireGlobalAdmin(user) {
  if (!user || user.role !== "admin") {
    return json({ ok: false, erro: "Acesso restrito ao administrador global" }, 403);
  }
  return null;
}
function requireAuth(user) {
  if (!user) {
    return json({ ok: false, erro: "Nao autenticado" }, 401);
  }
  return null;
}
async function audit(userId, action, entity, entityId = "", details = "") {
  await getSupabase().from("audit_log").insert({
    user_id: userId,
    action,
    entity,
    entity_id: entityId,
    details
  });
}
function escapeHtml(s) {
  if (!s) return "";
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function money(v) {
  const n = parseFloat(v) || 0;
  return n.toLocaleString("pt-BR", { minimumFractionDigits: 2 });
}
function datefmt(s) {
  if (!s) return "-";
  try {
    const d = new Date(s.slice(0, 10));
    return d.toLocaleDateString("pt-BR");
  } catch {
    return String(s);
  }
}
function today() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function safeFloat(value, def = 0) {
  if (value == null || value === "") return def;
  const n = parseFloat(value);
  return isNaN(n) ? def : n;
}
function validarCpfCnpj(valor) {
  const nums = String(valor).replace(/\D/g, "");
  if (nums.length === 11) {
    if (nums === nums[0].repeat(11)) return false;
    let s1 = 0;
    for (let i = 0; i < 9; i++) s1 += parseInt(nums[i]) * (10 - i);
    const d1 = s1 * 10 % 11 % 11;
    let s2 = 0;
    for (let i = 0; i < 10; i++) s2 += parseInt(nums[i]) * (11 - i);
    const d2 = s2 * 10 % 11 % 11;
    return parseInt(nums[9]) === d1 && parseInt(nums[10]) === d2;
  }
  if (nums.length === 14) {
    if (nums === nums[0].repeat(14)) return false;
    const p1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let s1 = 0;
    for (let i = 0; i < 12; i++) s1 += parseInt(nums[i]) * p1[i];
    let d1 = 11 - s1 % 11;
    if (d1 >= 10) d1 = 0;
    const p2 = [6, 5, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    let s2 = 0;
    for (let i = 0; i < 13; i++) s2 += parseInt(nums[i]) * p2[i];
    let d2 = 11 - s2 % 11;
    if (d2 >= 10) d2 = 0;
    return parseInt(nums[12]) === d1 && parseInt(nums[13]) === d2;
  }
  return true;
}
async function getEmailConfig() {
  const { data } = await getSupabase().from("email_config").select("*").eq("id", 1).single();
  if (!data) return {};
  const cfg = { ...data };
  if (cfg.email_senha_enc) {
    try {
      const decipher = import_crypto.default.createDecipheriv(
        "aes-256-cbc",
        import_crypto.default.createHash("sha256").update(JWT_SECRET).digest(),
        Buffer.from(cfg.email_senha_enc, "hex").slice(0, 16)
      );
      const encrypted = Buffer.from(cfg.email_senha_enc, "hex").slice(16);
      cfg.email_senha = decipher.update(encrypted) + decipher.final("utf8");
    } catch {
      cfg.email_senha = "";
    }
  }
  cfg.email_senha_enc = void 0;
  return cfg;
}
async function saveEmailConfig(cfg) {
  const data = { ...cfg };
  if (data.email_senha && data.email_senha !== "********") {
    const key = import_crypto.default.createHash("sha256").update(JWT_SECRET).digest();
    const iv = import_crypto.default.randomBytes(16);
    const cipher = import_crypto.default.createCipheriv("aes-256-cbc", key, iv);
    const encrypted = Buffer.concat([cipher.update(data.email_senha, "utf8"), cipher.final()]);
    data.email_senha_enc = Buffer.concat([iv, encrypted]).toString("hex");
  }
  delete data.email_senha;
  await getSupabase().from("email_config").upsert({ id: 1, ...data });
}
function processPayments(contratos, pagamentos, hoje, empresaNomes = {}) {
  const vencidos = [], venceHoje = [], venceAmanha = [];
  for (const p of pagamentos) {
    if (p.data_pagamento) continue;
    const venc = (p.vencimento || "").slice(0, 10);
    const dv = new Date(venc);
    if (isNaN(dv)) continue;
    const c = contratos.find((c2) => c2.id === p.contract_id);
    const diff = Math.floor((dv - new Date(hoje)) / 864e5);
    const info = {
      numero_contrato: p.contrato_num || (c ? c.numero : "?"),
      empresa: empresaNomes[c?.empresa_id] || "",
      parte: c ? c.fornecedor : "?",
      descricao: p.descricao || "?",
      vencimento: datefmt(venc),
      valor: money(p.valor || 0)
    };
    if (diff < 0) {
      info.dias = Math.abs(diff);
      vencidos.push(info);
    } else if (diff === 0) venceHoje.push(info);
    else if (diff === 1) venceAmanha.push(info);
  }
  return [vencidos, venceHoje, venceAmanha];
}
function processContratosVencidos(contratos, hoje) {
  const vencidos = [];
  const hj = new Date(hoje);
  for (const c of contratos) {
    const fim = (c.fim || "").slice(0, 10);
    const df = new Date(fim);
    if (isNaN(df)) continue;
    const diff = Math.floor((hj - df) / 864e5);
    if (diff <= 0) continue;
    vencidos.push({ numero: c.numero, fornecedor: c.fornecedor, objeto: c.objeto, fim: datefmt(fim), dias_passados: diff });
  }
  return vencidos;
}
function processContratosAVencer(contratos, hoje) {
  const grupos = { d35: [], d30: [], d15: [], d0_14: [] };
  const hj = new Date(hoje);
  for (const c of contratos) {
    const fim = (c.fim || "").slice(0, 10);
    const df = new Date(fim);
    if (isNaN(df)) continue;
    const diff = Math.floor((df - hj) / 864e5);
    if (diff < 0) continue;
    const info = { numero: c.numero, fornecedor: c.fornecedor, objeto: c.objeto, fim: datefmt(fim), dias: diff };
    if (diff >= 31 && diff <= 35) grupos.d35.push(info);
    else if (diff >= 16 && diff <= 30) grupos.d30.push(info);
    else if (diff === 15) grupos.d15.push(info);
    else if (diff >= 0 && diff <= 14) grupos.d0_14.push(info);
  }
  return grupos;
}
function montarHtmlPagamentos(vencidos, venceHoje, venceAmanha, tituloExtra = "") {
  let html = `<h2 style="color:#1a3c5e">Lembrete de Vencimentos${escapeHtml(tituloExtra)}</h2>`;
  if (vencidos.length) {
    html += `<h3 style="color:#c0392b">VENCIDOS</h3><table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;margin-bottom:20px"><tr style="background:#ffe1e1"><th>Contrato</th><th>Fornecedor</th><th>Parcela</th><th>Vencimento</th><th>Valor</th><th>Dias</th></tr>`;
    for (const v of vencidos) html += `<tr><td>${escapeHtml(v.numero_contrato)}</td><td>${escapeHtml(v.parte)}</td><td>${escapeHtml(v.descricao)}</td><td>${escapeHtml(v.vencimento)}</td><td>R$ ${escapeHtml(v.valor)}</td><td>${v.dias} dia(s)</td></tr>`;
    html += "</table>";
  }
  if (venceHoje.length) {
    html += `<h3 style="color:#d4820a">VENCEM HOJE</h3><table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;margin-bottom:20px"><tr style="background:#fff3cd"><th>Contrato</th><th>Fornecedor</th><th>Parcela</th><th>Vencimento</th><th>Valor</th></tr>`;
    for (const v of venceHoje) html += `<tr><td>${escapeHtml(v.numero_contrato)}</td><td>${escapeHtml(v.parte)}</td><td>${escapeHtml(v.descricao)}</td><td>${escapeHtml(v.vencimento)}</td><td>R$ ${escapeHtml(v.valor)}</td></tr>`;
    html += "</table>";
  }
  if (venceAmanha.length) {
    html += `<h3 style="color:#24527a">VENCEM AMANHA</h3><table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;margin-bottom:20px"><tr style="background:#eef6ff"><th>Contrato</th><th>Fornecedor</th><th>Parcela</th><th>Vencimento</th><th>Valor</th></tr>`;
    for (const v of venceAmanha) html += `<tr><td>${escapeHtml(v.numero_contrato)}</td><td>${escapeHtml(v.parte)}</td><td>${escapeHtml(v.descricao)}</td><td>${escapeHtml(v.vencimento)}</td><td>R$ ${escapeHtml(v.valor)}</td></tr>`;
    html += "</table>";
  }
  return html;
}
function montarHtmlContratos(vencidos, grupos, tituloExtra = "") {
  let html = "";
  if (vencidos.length) {
    html += `<h2 style="color:#c0392b">Contratos Vencidos${escapeHtml(tituloExtra)}</h2><table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;margin-bottom:20px"><tr style="background:#ffe1e1"><th>Contrato</th><th>Fornecedor</th><th>Objeto</th><th>Termino</th><th>Dias</th></tr>`;
    for (const c of vencidos) html += `<tr><td>${escapeHtml(c.numero)}</td><td>${escapeHtml(c.fornecedor)}</td><td>${escapeHtml(c.objeto)}</td><td>${escapeHtml(c.fim)}</td><td>${c.dias_passados} dia(s)</td></tr>`;
    html += "</table>";
  }
  const secoes = [
    ["d35", "ENTRE 31 E 35 DIAS", "#24527a", "#eef6ff"],
    ["d30", "ENTRE 16 E 30 DIAS", "#d4820a", "#fff3cd"],
    ["d15", "FALTAM 15 DIAS", "#c0392b", "#ffe1e1"],
    ["d0_14", "MENOS DE 15 DIAS", "#b71c1c", "#ffd7d7"]
  ];
  for (const [chave, titulo, cor, bg] of secoes) {
    const grupo = grupos[chave];
    if (!grupo?.length) continue;
    if (html) html += `<h2 style="color:#1a3c5e">Aviso de Vencimento${escapeHtml(tituloExtra)}</h2>`;
    html += `<h3 style="color:${cor}">${titulo}</h3><table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse;width:100%;margin-bottom:20px"><tr style="background:${bg}"><th>Contrato</th><th>Fornecedor</th><th>Objeto</th><th>Termino</th><th>Dias</th></tr>`;
    for (const c of grupo) html += `<tr><td>${escapeHtml(c.numero)}</td><td>${escapeHtml(c.fornecedor)}</td><td>${escapeHtml(c.objeto)}</td><td>${escapeHtml(c.fim)}</td><td>${c.dias} dia(s)</td></tr>`;
    html += "</table>";
  }
  return html;
}
async function enviarEmail(cfg, html, assunto, destinatario) {
  const transporter = import_nodemailer.default.createTransport({
    host: cfg.smtp_server || "smtp.gmail.com",
    port: parseInt(cfg.smtp_port) || 587,
    secure: false,
    auth: { user: cfg.email_remetente, pass: cfg.email_senha }
  });
  await transporter.sendMail({
    from: cfg.email_remetente,
    to: destinatario,
    subject: assunto,
    html
  });
}
async function handler(event) {
  const { path, httpMethod, headers, body: rawBody } = event;
  const body = rawBody ? JSON.parse(rawBody) : {};
  const cookieHeader = headers.cookie || "";
  if (!body.csrf_token && headers["x-csrf-token"]) body.csrf_token = headers["x-csrf-token"];
  const host = headers.host || "";
  const isSecure = process.env.HTTPS === "1" || host.includes("netlify.app");
  const user = getAuthUser(cookieHeader);
  const csrfToken = user ? user._csrfToken || deriveCsrf(user.id) : "";
  if (user) {
    const maxHours = parseInt(process.env.SESSION_TIMEOUT_HOURS || "8");
    const now = Math.floor(Date.now() / 1e3);
    if (user._lastActive && now - user._lastActive > maxHours * 3600) {
      return json({ ok: false, erro: "Sessao expirada. Faca login novamente." }, 401, {
        "Set-Cookie": "token=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"
      });
    }
    user._lastActive = now;
  }
  const route = path.replace("/api/", "");
  const parts = route.split("/");
  try {
    if (route === "csrf-token" && httpMethod === "GET") {
      return json({ csrf_token: csrfToken });
    }
    if (route === "me" && httpMethod === "GET") {
      if (!user) return json({ ok: false, user: null }, 401);
      const { data: dbUser } = await getSupabase().from("users").select("id, username, full_name, role").eq("id", user.id).single();
      return json({ ok: true, user: dbUser, csrf_token: csrfToken });
    }
    if (route === "login" && httpMethod === "POST") {
      const { username, password } = body;
      const { data: dbUser } = await getSupabase().from("users").select("*").eq("username", username).eq("active", 1).single();
      if (!dbUser || !await checkPassword(password, dbUser.password_hash)) {
        return json({ ok: false, erro: "Usuario ou senha incorretos!" }, 401);
      }
      const now = Math.floor(Date.now() / 1e3);
      const sessionCsrf = import_crypto.default.randomBytes(32).toString("hex");
      const token = import_jsonwebtoken.default.sign(
        { id: dbUser.id, username: dbUser.username, full_name: dbUser.full_name, role: dbUser.role, _lastActive: now, _csrfToken: sessionCsrf },
        JWT_SECRET,
        { expiresIn: "8h" }
      );
      await audit(dbUser.id, "LOGIN", "user", String(dbUser.id), `Login: ${dbUser.username}`);
      return json({
        ok: true,
        user: { id: dbUser.id, username: dbUser.username, full_name: dbUser.full_name, role: dbUser.role },
        csrf_token: sessionCsrf
      }, 200, {
        "Set-Cookie": setCookie("token", token, { secure: isSecure, maxAge: 28800 })
      });
    }
    if (route === "logout" && httpMethod === "POST") {
      if (user) await audit(user.id, "LOGOUT", "user", String(user.id), `Logout: ${user.username}`);
      return json({ ok: true }, 200, {
        "Set-Cookie": "token=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"
      });
    }
    if (route === "change-password" && httpMethod === "POST") {
      if (!user) return json({ ok: false, erro: "Nao autenticado" }, 401);
      if (!validateCsrf(user, body.csrf_token)) return json({ ok: false, erro: "CSRF invalido" }, 403);
      const { current_password, new_password } = body;
      if (!current_password || !new_password) return json({ ok: false, erro: "Senha atual e nova senha sao obrigatorias." }, 400);
      const { data: dbUser } = await getSupabase().from("users").select("*").eq("id", user.id).single();
      if (!dbUser) return json({ ok: false, erro: "Usuario nao encontrado." }, 400);
      const valid = await hashPassword(current_password);
      const pwHash = dbUser.password_hash || "";
      const bcryptValid = await bcrypt.compare(current_password, pwHash).catch(() => false);
      if (!bcryptValid) return json({ ok: false, erro: "Senha atual incorreta." }, 400);
      if (new_password.length < 8) return json({ ok: false, erro: "Nova senha deve ter no minimo 8 caracteres." }, 400);
      if (!/[A-Z]/.test(new_password)) return json({ ok: false, erro: "Nova senha deve conter pelo menos 1 letra maiuscula." }, 400);
      if (!/[a-z]/.test(new_password)) return json({ ok: false, erro: "Nova senha deve conter pelo menos 1 letra minuscula." }, 400);
      if (!/[0-9]/.test(new_password)) return json({ ok: false, erro: "Nova senha deve conter pelo menos 1 numero." }, 400);
      const newHash = await hashPassword(new_password);
      await getSupabase().from("users").update({ password_hash: newHash, password_changed_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", user.id);
      await audit(user.id, "CHANGE_PASSWORD", "user", String(user.id), "Senha alterada pelo proprio usuario");
      return json({ ok: true, msg: "Senha alterada com sucesso!" });
    }
    if (route === "forgot-password" && httpMethod === "POST") {
      const clientIp = headers["x-forwarded-for"] || headers["client-ip"] || "unknown";
      if (!checkForgotPasswordRateLimit(clientIp)) {
        return json({ ok: false, erro: "Muitas tentativas. Aguarde 1 minuto." }, 429);
      }
      const { username } = body;
      if (!username) return json({ ok: false, erro: "Informe o nome de usuario." }, 400);
      const { data: dbUser } = await getSupabase().from("users").select("*").eq("username", username).single();
      if (!dbUser) return json({ ok: true, msg: "Se o usuario existir, um email sera enviado." });
      const token = import_crypto.default.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 60 * 60 * 1e3).toISOString();
      await getSupabase().from("password_resets").insert({
        user_id: dbUser.id,
        token,
        expires_at: expiresAt
      });
      const cfg = await getEmailConfig();
      const emailTo = dbUser.email || cfg.email_remetente;
      if (cfg.email_remetente && cfg.email_senha && emailTo) {
        const resetUrl = `https://${headers.host || "contratosidealalimentacao.netlify.app"}/?reset_token=${token}`;
        const html = `<h2>Redefinicao de Senha</h2><p>Ola ${escapeHtml(dbUser.full_name)},</p><p>Clique no link abaixo para redefinir sua senha:</p><p><a href="${resetUrl}">${resetUrl}</a></p><p>Este link expira em 1 hora.</p><p>Se voce nao solicitou esta redefinicao, ignore este email.</p>`;
        try {
          await enviarEmail(cfg, html, "Redefinicao de Senha - Controle de Contratos", emailTo);
        } catch {
        }
      }
      return json({ ok: true, msg: "Se o usuario existir, um email sera enviado." });
    }
    if (route === "reset-password" && httpMethod === "POST") {
      const { token, password } = body;
      if (!token || !password) return json({ ok: false, erro: "Token e nova senha sao obrigatorios." }, 400);
      if (password.length < 8) return json({ ok: false, erro: "A senha deve ter no minimo 8 caracteres." }, 400);
      if (!/[A-Z]/.test(password)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 letra maiuscula." }, 400);
      if (!/[a-z]/.test(password)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 letra minuscula." }, 400);
      if (!/[0-9]/.test(password)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 numero." }, 400);
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const { data: reset } = await getSupabase().from("password_resets").select("*").eq("token", token).eq("used", 0).single();
      if (!reset) return json({ ok: false, erro: "Token invalido ou ja utilizado." }, 400);
      if (reset.expires_at < now) return json({ ok: false, erro: "Token expirado. Solicite uma nova redefinicao." }, 400);
      const hash = await hashPassword(password);
      await getSupabase().from("users").update({ password_hash: hash }).eq("id", reset.user_id);
      await getSupabase().from("password_resets").update({ used: 1 }).eq("id", reset.id);
      return json({ ok: true, msg: "Senha redefinida com sucesso!" });
    }
    if (route === "config-email") {
      if (httpMethod === "GET") {
        const cfg = await getEmailConfig();
        cfg.email_senha = "********";
        return json(cfg);
      }
      if (httpMethod === "POST") {
        const authErr = requireAuth(user);
        if (authErr) return authErr;
        if (!validateCsrf(user, body.csrf_token)) {
          return json({ ok: false, erro: "CSRF invalido" }, 403);
        }
        const { data: oldCfg } = await getSupabase().from("email_config").select("*").eq("id", 1).single();
        if (body.email_senha === "********" || !body.email_senha?.trim()) {
          body.email_senha = oldCfg?.email_senha_enc ? "********" : "";
          body.email_senha_enc = oldCfg?.email_senha_enc || "";
        }
        await saveEmailConfig(body);
        return json({ ok: true });
      }
    }
    if (route === "enviar-lembrete" || route === "enviar-lembrete-pagamentos") {
      if (httpMethod !== "POST") return json({ ok: false, erro: "Metodo nao permitido" }, 405);
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const cfg = await getEmailConfig();
      if (!cfg.email_remetente || !cfg.email_senha) {
        return json({ ok: false, erro: "Configure o e-mail primeiro." });
      }
      const empresasLista = body.empresas || [];
      const empresaNomes = {};
      for (const e of empresasLista) {
        if (e.id && e.nome) empresaNomes[e.id] = e.nome;
      }
      const destinatariosData = body.destinatarios || [];
      if (!destinatariosData.length) {
        return json({ ok: true, msg: "Nenhum destinatario cadastrado para enviar lembretes." });
      }
      const { data: contratos } = await getSupabase().from("contracts").select("*");
      const { data: pagamentos } = await getSupabase().from("payments").select("*");
      const hj = today();
      let enviados = 0, erros = [];
      for (const dest of destinatariosData) {
        const email = (dest.email || "").trim();
        if (!email) continue;
        const empresaIds = dest.empresaIds || [];
        const empIdsSet = empresaIds.length ? new Set(empresaIds) : null;
        const contratoIdsEmp = new Set(contratos.filter((c) => !empIdsSet || empIdsSet.has(c.empresa_id)).map((c) => c.id));
        const empPagamentos = pagamentos.filter((p) => contratoIdsEmp.has(p.contract_id));
        const [vencidos, venceHoje, venceAmanha] = processPayments(contratos, empPagamentos, hj, empresaNomes);
        if (!vencidos.length && !venceHoje.length && !venceAmanha.length) continue;
        const rotulo = dest.nome ? ` - ${dest.nome}` : "";
        const htmlBody = `<html><body style="font-family:Arial,sans-serif;padding:20px">${montarHtmlPagamentos(vencidos, venceHoje, venceAmanha, rotulo)}<p style="color:#666;font-size:12px">Gerado em ${(/* @__PURE__ */ new Date()).toLocaleString("pt-BR")}</p></body></html>`;
        try {
          await enviarEmail(cfg, htmlBody, `Lembrete de Pagamentos${rotulo} - ${hj}`, email);
          enviados++;
        } catch (e) {
          erros.push(`${email}: ${e.message}`);
        }
      }
      if (!enviados && !erros.length) return json({ ok: true, msg: "Nenhum pagamento pendente para os destinatarios cadastrados." });
      return json({ ok: true, msg: `${enviados} e-mail(s) enviado(s).${erros.length ? ` Erros: ${erros.join("; ")}` : ""}` });
    }
    if (route === "enviar-alertas-contratos") {
      if (httpMethod !== "POST") return json({ ok: false, erro: "Metodo nao permitido" }, 405);
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const cfg = await getEmailConfig();
      if (!cfg.email_remetente || !cfg.email_senha) {
        return json({ ok: false, erro: "Configure o e-mail primeiro." });
      }
      const destinatariosData = body.destinatarios || [];
      if (!destinatariosData.length) {
        return json({ ok: true, msg: "Nenhum destinatario cadastrado para enviar alertas." });
      }
      const { data: contratos } = await getSupabase().from("contracts").select("*");
      const hj = today();
      let enviados = 0, erros = [];
      for (const dest of destinatariosData) {
        const email = (dest.email || "").trim();
        if (!email) continue;
        const empresaIds = dest.empresaIds || [];
        const empIdsSet = empresaIds.length ? new Set(empresaIds) : null;
        const empContratos = contratos.filter((c) => !empIdsSet || empIdsSet.has(c.empresa_id));
        const vencidos = processContratosVencidos(empContratos, hj);
        const grupos = processContratosAVencer(empContratos, hj);
        if (!vencidos.length && !Object.values(grupos).some((g) => g.length)) continue;
        const rotulo = dest.nome ? ` - ${dest.nome}` : "";
        const htmlBody = `<html><body style="font-family:Arial,sans-serif;padding:20px">${montarHtmlContratos(vencidos, grupos, rotulo)}<p style="color:#666;font-size:12px">Gerado em ${(/* @__PURE__ */ new Date()).toLocaleString("pt-BR")}</p></body></html>`;
        try {
          await enviarEmail(cfg, htmlBody, `Alertas de Contratos${rotulo} - ${hj}`, email);
          enviados++;
        } catch (e) {
          erros.push(`${email}: ${e.message}`);
        }
      }
      if (!enviados && !erros.length) return json({ ok: true, msg: "Nenhum contrato pendente para os destinatarios cadastrados." });
      return json({ ok: true, msg: `${enviados} e-mail(s) enviado(s).${erros.length ? ` Erros: ${erros.join("; ")}` : ""}` });
    }
    if (route === "users" && httpMethod === "GET") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireAdmin(user);
      if (adminErr) return adminErr;
      const { data: users } = await getSupabase().from("users").select("id, username, full_name, role, active, created_at").order("id");
      return json(users);
    }
    if (route === "users" && httpMethod === "POST") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireAdmin(user);
      if (adminErr) return adminErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const username = (body.username || "").trim();
      const fullName = (body.full_name || "").trim();
      const email = (body.email || "").trim();
      const password = (body.password || "").trim();
      const role = (body.role || "user").trim();
      if (!username || !fullName || !password) {
        return json({ ok: false, erro: "Preencha todos os campos" }, 400);
      }
      if (email && !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
        return json({ ok: false, erro: "Email invalido" }, 400);
      }
      if (password.length < 8) return json({ ok: false, erro: "Senha deve ter no minimo 8 caracteres." }, 400);
      if (!/[A-Z]/.test(password)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 letra maiuscula." }, 400);
      if (!/[a-z]/.test(password)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 letra minuscula." }, 400);
      if (!/[0-9]/.test(password)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 numero." }, 400);
      const { data: existing } = await getSupabase().from("users").select("id").eq("username", username).single();
      if (existing) return json({ ok: false, erro: "Usuario ja existe" }, 400);
      const hash = await hashPassword(password);
      const { data: newUser } = await getSupabase().from("users").insert({
        username,
        full_name: fullName,
        email,
        password_hash: hash,
        role
      }).select().single();
      await audit(user.id, "CREATE", "user", "", `Usuario ${username} criado por ${user.username}`);
      return json({ ok: true, user: { id: newUser.id } });
    }
    if (parts[0] === "users" && parts[1] && httpMethod === "PUT") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireAdmin(user);
      if (adminErr) return adminErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const uid = parseInt(parts[1]);
      const fullName = (body.full_name || "").trim();
      const email = (body.email || "").trim();
      const role = (body.role || "user").trim();
      const active = body.active !== false ? 1 : 0;
      if (email && !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(email)) {
        return json({ ok: false, erro: "Email invalido" }, 400);
      }
      const upd = { full_name: fullName, email, role, active };
      if (body.password && body.password.trim()) {
        const pwd = body.password.trim();
        if (pwd.length < 8) return json({ ok: false, erro: "Senha deve ter no minimo 8 caracteres." }, 400);
        if (!/[A-Z]/.test(pwd)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 letra maiuscula." }, 400);
        if (!/[a-z]/.test(pwd)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 letra minuscula." }, 400);
        if (!/[0-9]/.test(pwd)) return json({ ok: false, erro: "Senha deve conter pelo menos 1 numero." }, 400);
        upd.password_hash = await hashPassword(pwd);
      }
      await getSupabase().from("users").update(upd).eq("id", uid);
      await audit(user.id, "UPDATE", "user", String(uid), `Usuario ${uid} atualizado por ${user.username}`);
      return json({ ok: true });
    }
    if (parts[0] === "users" && parts[1] && httpMethod === "DELETE") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireAdmin(user);
      if (adminErr) return adminErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const uid = parseInt(parts[1]);
      if (uid === 1) return json({ ok: false, erro: "Nao e possivel inativar o usuario admin principal." }, 400);
      await getSupabase().from("users").update({ active: 0 }).eq("id", uid);
      await audit(user.id, "INACTIVATE", "user", String(uid), `Usuario ${uid} inativado por ${user.username}`);
      return json({ ok: true });
    }
    if (route === "companies" && httpMethod === "GET") {
      const { data } = await getSupabase().from("companies").select("*").order("nome");
      return json(data);
    }
    if (route === "companies" && httpMethod === "POST") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const cid = body.id || import_crypto.default.randomUUID();
      const nome = (body.nome || "").trim();
      if (!nome) return json({ ok: false, erro: "Nome da empresa e obrigatorio." }, 400);
      const cnpj = (body.cnpj || "").trim();
      const { data: existing } = await getSupabase().from("companies").select("id").eq("id", cid).single();
      const active = body.active !== void 0 ? body.active ? 1 : 0 : 1;
      if (existing) {
        await getSupabase().from("companies").update({ nome, cnpj, active }).eq("id", cid);
      } else {
        await getSupabase().from("companies").insert({ id: cid, nome, cnpj, active });
      }
      return json({ ok: true, id: cid });
    }
    if (parts[0] === "companies" && parts[1] && httpMethod === "PUT") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const upd = {};
      if (body.active !== void 0) upd.active = body.active ? 1 : 0;
      if (body.nome !== void 0) upd.nome = (body.nome || "").trim();
      if (body.cnpj !== void 0) upd.cnpj = (body.cnpj || "").trim();
      await getSupabase().from("companies").update(upd).eq("id", parts[1]);
      return json({ ok: true });
    }
    if (parts[0] === "companies" && parts[1] && httpMethod === "DELETE") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireGlobalAdmin(user);
      if (adminErr) return adminErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      await getSupabase().from("companies").delete().eq("id", parts[1]);
      return json({ ok: true });
    }
    if (route === "sectors" && httpMethod === "GET") {
      const { data } = await getSupabase().from("sectors").select("*").order("nome");
      return json(data || []);
    }
    if (route === "sectors" && httpMethod === "POST") {
      const authErr = requireGlobalAdmin(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const sid = body.id || import_crypto.default.randomUUID();
      const nome = (body.nome || "").trim();
      if (!nome) return json({ ok: false, erro: "Nome do setor e obrigatorio." }, 400);
      const active = body.active !== void 0 ? body.active ? 1 : 0 : 1;
      const { data: existing } = await getSupabase().from("sectors").select("id").eq("id", sid).maybeSingle();
      if (existing) {
        await getSupabase().from("sectors").update({ nome, active }).eq("id", sid);
      } else {
        await getSupabase().from("sectors").insert({ id: sid, nome, active });
      }
      return json({ ok: true, id: sid });
    }
    if (parts[0] === "sectors" && parts[1] && httpMethod === "PUT") {
      const authErr = requireGlobalAdmin(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const upd = {};
      if (body.active !== void 0) upd.active = body.active ? 1 : 0;
      if (body.nome !== void 0) upd.nome = (body.nome || "").trim();
      await getSupabase().from("sectors").update(upd).eq("id", parts[1]);
      return json({ ok: true });
    }
    if (parts[0] === "sectors" && parts[1] && httpMethod === "DELETE") {
      const authErr = requireGlobalAdmin(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      await getSupabase().from("user_setores").delete().eq("setor_id", parts[1]);
      await getSupabase().from("sectors").delete().eq("id", parts[1]);
      return json({ ok: true });
    }
    if (parts[0] === "contracts" && parts[1] && httpMethod === "PUT") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      const upd = {};
      if (body.active !== void 0) upd.active = body.active ? 1 : 0;
      await getSupabase().from("contracts").update(upd).eq("id", parts[1]);
      return json({ ok: true });
    }
    if (parts[0] === "contracts" && parts[1] && httpMethod === "DELETE") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireGlobalAdmin(user);
      if (adminErr) return adminErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      await getSupabase().from("payments").delete().eq("contract_id", parts[1]);
      await getSupabase().from("additives").delete().eq("contract_id", parts[1]);
      await getSupabase().from("contracts").delete().eq("id", parts[1]);
      await audit(user.id, "DELETE", "contract", parts[1], `Contrato ${parts[1]} excluido por ${user.username}`);
      return json({ ok: true });
    }
    if (parts[0] === "payments" && parts[1] && httpMethod === "DELETE") {
      const authErr = requireAuth(user);
      if (authErr) return authErr;
      const adminErr = requireGlobalAdmin(user);
      if (adminErr) return adminErr;
      if (!validateCsrf(user, body.csrf_token)) {
        return json({ ok: false, erro: "CSRF invalido" }, 403);
      }
      await getSupabase().from("payments").delete().eq("id", parts[1]);
      await audit(user.id, "DELETE", "payment", parts[1], `Pagamento ${parts[1]} excluido por ${user.username}`);
      return json({ ok: true });
    }
    if (route === "sync") {
      if (httpMethod === "GET") {
        const authErr = requireAuth(user);
        if (authErr) return authErr;
        const [contratos, pagamentos, usuarios, aditivos, empresas, destinatarios, sectors] = await Promise.all([
          getSupabase().from("contracts").select("*").order("created_at", { ascending: false }),
          getSupabase().from("payments").select("*").order("vencimento"),
          getSupabase().from("users").select("id, username, full_name, role, created_at").order("id"),
          getSupabase().from("additives").select("*").order("created_at"),
          getSupabase().from("companies").select("*").order("nome"),
          getSupabase().from("destinatarios").select("*").order("criado_em"),
          getSupabase().from("sectors").select("*").order("nome")
        ]);
        return json({
          contratos: contratos.data || [],
          pagamentos: pagamentos.data || [],
          usuarios: usuarios.data || [],
          aditivos: aditivos.data || [],
          empresas: empresas.data || [],
          destinatarios: destinatarios.data || [],
          sectors: sectors.data || []
        });
      }
      if (httpMethod === "POST") {
        const authErr = requireAuth(user);
        if (authErr) return authErr;
        if (!validateCsrf(user, body.csrf_token)) {
          return json({ ok: false, erro: "CSRF invalido" }, 403);
        }
        if (!body) return json({ ok: false, erro: "JSON invalido ou vazio." }, 400);
        const importados = { contratos: 0, pagamentos: 0, aditivos: 0, ignorados: 0 };
        const MAX_BASE64 = 15 * 1024 * 1024;
        for (const c of body.contratos || []) {
          const cid = (c.id || "").trim();
          const numero = (c.numero || "").trim();
          if (!cid || !numero) {
            importados.ignorados++;
            continue;
          }
          if (c.arquivo?.data?.length > MAX_BASE64) {
            return json({ ok: false, erro: `Arquivo do contrato ${numero} excede 10MB.` }, 400);
          }
          const cnpjVal = (c.doc || "").trim();
          if (cnpjVal && !validarCpfCnpj(cnpjVal)) {
            return json({ ok: false, erro: `CPF/CNPJ invalido no contrato ${numero}: ${cnpjVal}` }, 400);
          }
          const pgto = c.pgtoConfig || {};
          const arquivoJson = c.arquivo ? JSON.stringify(c.arquivo) : null;
          const { data: existing } = await getSupabase().from("contracts").select("id").eq("id", cid).single();
          const vals = {
            numero,
            fornecedor: (c.parte || "").trim(),
            cnpj: (c.doc || "").trim(),
            objeto: (c.objeto || "").trim(),
            valor_total: parseFloat(c.valor || 0),
            inicio: (c.inicio || "").trim(),
            fim: (c.fim || "").trim(),
            tem_parcelas: c.temParcelas ? 1 : 0,
            qtd_parcelas: pgto.qtdParcelas,
            valor_parcela: safeFloat(pgto.valorParcela),
            dia_vencimento: pgto.diaVenc,
            responsavel: (c.responsavel || "").trim(),
            setor: (c.setor || "").trim(),
            obs: (c.obs || "").trim(),
            tipo: c.tipo,
            empresa_id: c.empresaId,
            active: c.active !== void 0 ? c.active ? 1 : 0 : 1,
            forma_pagamento: pgto.forma,
            arquivo_contrato: arquivoJson
          };
          if (existing) {
            await getSupabase().from("contracts").update({ ...vals, updated_at: (/* @__PURE__ */ new Date()).toISOString() }).eq("id", cid);
          } else {
            await getSupabase().from("contracts").insert({ id: cid, ...vals, created_by: 1 });
          }
          importados.contratos++;
          if (c.aditivos?.length) {
            await getSupabase().from("additives").delete().eq("contract_id", cid);
            for (const a of c.aditivos) {
              if (a.arquivo?.data?.length > MAX_BASE64) {
                return json({ ok: false, erro: "Arquivo de aditivo excede 10MB." }, 400);
              }
              const arqJson = a.arquivo ? JSON.stringify(a.arquivo) : null;
              await getSupabase().from("additives").insert({
                id: a.id || import_crypto.default.randomUUID(),
                contract_id: cid,
                numero: a.numero,
                data_aditivo: a.data || "",
                tipo: a.tipo,
                nova_data_fim: a.novaData,
                acrescimo_valor: a.novoValor,
                descricao: a.objeto || "",
                arquivo_contrato: arqJson,
                created_by: 1
              });
              importados.aditivos++;
            }
          }
        }
        const pagDados = body.pagamentos || [];
        const contratosPag = new Set(pagDados.filter((p) => p.contratoId).map((p) => p.contratoId));
        for (const cid of contratosPag) {
          await getSupabase().from("payments").delete().eq("contract_id", cid);
        }
        for (const p of pagDados) {
          const pid = (p.id || "").trim() || import_crypto.default.randomUUID();
          const cid = (p.contratoId || "").trim();
          const descricao = (p.descricao || "").trim();
          const vencimento = (p.vencimento || "").trim();
          if (!cid || !vencimento) {
            importados.ignorados++;
            continue;
          }
          if (p.comprovante?.data?.length > MAX_BASE64) {
            return json({ ok: false, erro: "Comprovante de pagamento excede 10MB." }, 400);
          }
          const valor = parseFloat(p.valor || 0);
          const dataPag = (p.dataPagamento || "").trim() || null;
          const comprovanteJson = p.comprovante ? JSON.stringify(p.comprovante) : null;
          await getSupabase().from("payments").insert({
            id: pid,
            contract_id: cid,
            descricao,
            vencimento,
            valor,
            contrato_num: (p.contratoNum || "").trim() || null,
            data_pagamento: dataPag,
            valor_pago: safeFloat(p.valorPago) || (dataPag ? valor : null),
            forma_pagamento: (p.formaPgto || "").trim() || null,
            status: dataPag ? "pago" : "pendente",
            obs: (p.obs || "").trim(),
            comprovante: comprovanteJson,
            created_by: 1
          });
          importados.pagamentos++;
        }
        for (const d of body.destinatarios || []) {
          const did = (d.id || "").trim();
          const email = (d.email || "").trim();
          if (!did || !email) {
            importados.ignorados++;
            continue;
          }
          const { data: existing } = await getSupabase().from("destinatarios").select("id").eq("id", did).single();
          if (existing) {
            await getSupabase().from("destinatarios").update({
              email,
              nome: (d.nome || "").trim(),
              empresa_ids: JSON.stringify(d.empresaIds || [])
            }).eq("id", did);
          } else {
            await getSupabase().from("destinatarios").insert({
              id: did,
              email,
              nome: (d.nome || "").trim(),
              empresa_ids: JSON.stringify(d.empresaIds || [])
            });
          }
          importados.destinatarios = (importados.destinatarios || 0) + 1;
        }
        for (const s of body.sectors || []) {
          const sid = (s.id || "").trim();
          const nome = (s.nome || "").trim();
          if (!sid || !nome) {
            importados.ignorados = (importados.ignorados || 0) + 1;
            continue;
          }
          const active = s.active !== void 0 ? s.active ? 1 : 0 : 1;
          const { data: existing } = await getSupabase().from("sectors").select("id").eq("id", sid).maybeSingle();
          if (existing) {
            await getSupabase().from("sectors").update({ nome, active }).eq("id", sid);
          } else {
            await getSupabase().from("sectors").insert({ id: sid, nome, active });
          }
          importados.sectors = (importados.sectors || 0) + 1;
        }
        await audit(user.id, "SYNC", "system", "", `Sincronizacao concluida: ${JSON.stringify(importados)}`);
        return json({ ok: true, importados });
      }
    }
    if (route === "assistente" && httpMethod === "POST") {
      const body2 = await readBody(event);
      const pergunta = (body2.pergunta || "").trim();
      if (!pergunta) return json({ ok: false, erro: "Pergunta vazia" }, 400);
      const geminiKey = process.env.GEMINI_API_KEY || "";
      if (!geminiKey) {
        return json({ ok: true, resposta: respostaOffline(pergunta) });
      }
      try {
        const prompt = SYSTEM_PROMPT_ASSISTENTE + "\n\nPERGUNTA DO USUARIO:\n" + pergunta.slice(0, 2e3);
        const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { temperature: 0.7, maxOutputTokens: 800 }
          })
        });
        const data = await resp.json();
        const texto = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        if (texto && texto.length > 10) {
          return json({ ok: true, resposta: texto });
        }
      } catch (e) {
        console.error("Gemini assistente falhou:", e.message);
      }
      return json({ ok: true, resposta: respostaOffline(pergunta) });
    }
    return json({ ok: false, erro: "Rota nao encontrada" }, 404);
  } catch (e) {
    console.error("API Error:", e);
    return json({ ok: false, erro: "Erro interno do servidor" }, 500);
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
